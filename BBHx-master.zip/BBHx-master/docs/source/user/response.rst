LISA Response Models
~~~~~~~~~~~~~~~~~~~~~~~~~~

Fast Frequency Domain Response
***********************************

.. autoclass:: bbhx.response.fastfdresponse.LISATDIResponse
    :members:
    :show-inheritance:
    :inherited-members:
