Available Waveform Models
~~~~~~~~~~~~~~~~~~~~~~~~~~

PhenomHM (PhenomD)
************************

.. autoclass:: bbhx.waveforms.phenomhm.PhenomHMAmpPhase
    :members:
    :show-inheritance:
    :inherited-members:
