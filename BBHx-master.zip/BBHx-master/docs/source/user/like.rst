Likelihood Methods
~~~~~~~~~~~~~~~~~~~~~~~~~~

Direct Likelihood Computation
*******************************

.. autoclass:: bbhx.likelihood.Likelihood
    :members:
    :show-inheritance:
    :inherited-members:
